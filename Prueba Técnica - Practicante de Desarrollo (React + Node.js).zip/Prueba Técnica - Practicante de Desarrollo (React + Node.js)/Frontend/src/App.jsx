// Importación de hooks de React y hoja de estilos
import { useEffect, useState } from 'react';
import '../src/App.css';

// URL base de la API
const API = 'http://localhost:3001/api/tareas';

function App() {
  // Estados para manejar tareas, formularios y errores
  const [tareas, setTareas] = useState([]);
  const [texto, setTexto] = useState('');
  const [categoria, setCategoria] = useState('Tareas personales');
  const [error, setError] = useState('');
  const [editandoId, setEditandoId] = useState(null);
  const [textoEditado, setTextoEditado] = useState('');
  const [categoriaEditada, setCategoriaEditada] = useState('Tareas personales');

  // Función para obtener todas las tareas desde el backend
  const obtenerTareas = async () => {
    try {
      const res = await fetch(API);
      const data = await res.json();

      // Ordena las tareas por fecha descendente (recientes primero)
      const ordenadas = data.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
      setTareas(ordenadas);
    } catch (err) {
      console.error('Error al obtener tareas:', err);
    }
  };

  // Función para agregar una nueva tarea
  const agregarTarea = async () => {
    if (!texto.trim()) {
      setError('Por favor ingresa una tarea.');
      return;
    }

    try {
      await fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ texto, categoria }),
      });

      // Limpia campos y vuelve a cargar tareas
      setTexto('');
      setCategoria('Tareas personales');
      setError('');
      obtenerTareas();
    } catch (err) {
      console.error('Error al agregar tarea:', err);
    }
  };

  // Función para eliminar una tarea
  const eliminarTarea = async (id) => {
    try {
      await fetch(`${API}/${id}`, { method: 'DELETE' });
      obtenerTareas(); // Recarga la lista
    } catch (err) {
      console.error('Error al eliminar tarea:', err);
    }
  };

  // Función para guardar los cambios al editar una tarea
  const guardarEdicion = async (id) => {
    if (!textoEditado.trim()) return;

    try {
      await fetch(`${API}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ texto: textoEditado, categoria: categoriaEditada }),
      });

      // Limpia los estados de edición
      setEditandoId(null);
      setTextoEditado('');
      obtenerTareas();
    } catch (err) {
      console.error('Error al editar tarea:', err);
    }
  };

  // useEffect para cargar las tareas al iniciar la app
  useEffect(() => {
    obtenerTareas();
  }, []);

  // Lista de categorías disponibles
  const categorias = ['Tareas personales', 'Tareas del hogar', 'Tareas laborales'];

  // Función que filtra tareas por categoría
  const tareasPorCategoria = (cat) => tareas.filter(t => t.categoria === cat);

  // Renderizado del componente
  return (
    <div className="container">
      <h1>📝 ToDo List</h1>

      {/* Formulario para agregar nueva tarea */}
      <div className="formulario">
        <input
          type="text"
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          placeholder="Escribe una tarea..."
        />
        <select value={categoria} onChange={(e) => setCategoria(e.target.value)}>
          {categorias.map(cat => <option key={cat} value={cat}>{cat}</option>)}
        </select>
        <button onClick={agregarTarea} className="btn agregar">➕</button>
      </div>

      {/* Mensaje de error */}
      {error && <p className="error">{error}</p>}

      {/* Sección para cada categoría */}
      {categorias.map(cat => (
        <div key={cat}>
          <h2>
            {/* Icono por tipo de categoría */}
            {cat === 'Tareas del hogar' ? '🏠' : cat === 'Tareas laborales' ? '💼' : '👤'} {cat}
          </h2>

          <ul className="lista-tareas">
            {/* Si no hay tareas en esta categoría */}
            {tareasPorCategoria(cat).length === 0 ? (
              <p className="vacio">No hay tareas en esta categoría 🎉</p>
            ) : (
              tareasPorCategoria(cat).map((tarea) => (
                <li key={tarea.id} className="tarea">
                  {editandoId === tarea.id ? (
                    // Si estamos editando esta tarea
                    <>
                      <input
                        type="text"
                        value={textoEditado}
                        onChange={(e) => setTextoEditado(e.target.value)}
                      />
                      <select value={categoriaEditada} onChange={(e) => setCategoriaEditada(e.target.value)}>
                        {categorias.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                      </select>
                      <div className="botones">
                        <button onClick={() => guardarEdicion(tarea.id)} className="btn guardar">📂</button>
                      </div>
                    </>
                  ) : (
                    // Vista normal de la tarea
                    <>
                      <span>{tarea.texto} <small>({tarea.categoria})</small></span>
                      <div className="botones">
                        <button
                          onClick={() => {
                            // Activar modo edición
                            setEditandoId(tarea.id);
                            setTextoEditado(tarea.texto);
                            setCategoriaEditada(tarea.categoria);
                          }}
                          className="btn editar"
                        >🖊</button>
                        <button onClick={() => eliminarTarea(tarea.id)} className="btn eliminar">🗑</button>
                      </div>
                    </>
                  )}
                </li>
              ))
            )}
          </ul>
        </div>
      ))}
    </div>
  );
}

// Exportamos el componente principal
export default App;
