const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

const filePath = path.join(__dirname, 'tareas.json');
let tareas = [];
let id = 1;

// Leer tareas al iniciar
const cargarTareas = () => {
  if (fs.existsSync(filePath)) {
    const data = fs.readFileSync(filePath, 'utf-8');
    tareas = JSON.parse(data);
    id = tareas.length > 0 ? Math.max(...tareas.map(t => t.id)) + 1 : 1;
  }
};

// Guardar tareas
const guardarTareas = () => {
  fs.writeFileSync(filePath, JSON.stringify(tareas, null, 2));
};

// Cargar al iniciar
cargarTareas();

// Obtener tareas
app.get('/api/tareas', (req, res) => {
  res.json(tareas);
});

// Crear tarea
app.post('/api/tareas', (req, res) => {
  const { texto, categoria } = req.body;
  if (!texto || !categoria) {
    return res.status(400).json({ error: 'Texto y categoría requeridos' });
  }

  const nuevaTarea = {
    id: id++,
    texto,
    categoria,
    fecha: new Date().toISOString(),
  };

  tareas.push(nuevaTarea);
  guardarTareas();
  res.status(201).json(nuevaTarea);
});

// Eliminar tarea
app.delete('/api/tareas/:id', (req, res) => {
  const tareaId = parseInt(req.params.id);
  tareas = tareas.filter((t) => t.id !== tareaId);
  guardarTareas();
  res.status(204).send();
});

// Editar tarea
app.put('/api/tareas/:id', (req, res) => {
  const tareaId = parseInt(req.params.id);
  const { texto, categoria } = req.body;

  const tarea = tareas.find((t) => t.id === tareaId);
  if (!tarea) {
    return res.status(404).json({ mensaje: 'Tarea no encontrada' });
  }

  if (texto) tarea.texto = texto;
  if (categoria) tarea.categoria = categoria;

  guardarTareas();
  res.json(tarea);
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
